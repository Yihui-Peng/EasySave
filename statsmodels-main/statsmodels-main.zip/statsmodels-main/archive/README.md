This directory holds files that were once part of statsmodels but
are no longer maintained.  They are retained here in order to have their
git histories readily available, but should *not* be considered usable.
