from statsmodels.tools._test_runner import PytestTester

test = PytestTester()
