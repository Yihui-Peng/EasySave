.. _whatsnew_index:

=============
Release Notes
=============

.. toctree::
   :maxdepth: 1

   version0.14.4
   version0.14.3
   version0.14.2
   version0.14.1
   version0.14.0
   version0.13.4-5
   version0.13.3
   version0.13.2
   version0.13.1
   version0.13.0
   version0.12.1
   version0.12
   version0.11.1
   version0.11
   version0.10.2
   version0.10.1
   version0.10
   version0.9
   version0.8
   version0.7
   version0.6
   version0.5

For an overview of changes that occurred previous to the 0.5.0 release
see :ref:`old_changes`.

