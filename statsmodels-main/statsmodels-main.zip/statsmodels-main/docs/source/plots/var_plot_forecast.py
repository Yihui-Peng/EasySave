from var_plots import plot_forecast

plot_forecast()
